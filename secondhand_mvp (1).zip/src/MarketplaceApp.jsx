import { useState } from "react";

const sampleProducts = [
  {
    id: 1,
    title: "Apple Watch Series 7",
    brand: "Apple",
    condition: "Like New",
    price: "$250",
    image: "https://via.placeholder.com/300x200",
    description: "Used only for 2 months, no scratches."
  },
  {
    id: 2,
    title: "Gucci Leather Bag",
    brand: "Gucci",
    condition: "Excellent",
    price: "$600",
    image: "https://via.placeholder.com/300x200",
    description: "Lightly used for one event."
  }
];

export default function MarketplaceApp() {
  const [user, setUser] = useState(null);
  const [products, setProducts] = useState(sampleProducts);
  const [newProduct, setNewProduct] = useState({
    title: "",
    brand: "",
    condition: "",
    price: "",
    image: "",
    description: ""
  });

  const handleLogin = () => setUser({ name: "Seller123" });
  const handlePost = () => {
    setProducts([...products, { ...newProduct, id: Date.now() }]);
    setNewProduct({ title: "", brand: "", condition: "", price: "", image: "", description: "" });
  };

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Second-Hand Branded Goods</h1>

      {!user ? (
        <div>
          <button onClick={handleLogin} className="bg-blue-600 text-white px-4 py-2 rounded">Login as Seller</button>
        </div>
      ) : (
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-2">Post New Product</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {Object.entries(newProduct).map(([key, val]) => (
              <input
                key={key}
                className="border rounded px-2 py-1"
                placeholder={key.charAt(0).toUpperCase() + key.slice(1)}
                value={val}
                onChange={(e) => setNewProduct({ ...newProduct, [key]: e.target.value })}
              />
            ))}
          </div>
          <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded" onClick={handlePost}>Post Product</button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {products.map((product) => (
          <div key={product.id} className="border rounded overflow-hidden shadow">
            <img src={product.image} alt={product.title} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-lg font-semibold">{product.title}</h3>
              <p className="text-sm text-gray-500">{product.brand} - {product.condition}</p>
              <p className="text-md font-bold mt-1">{product.price}</p>
              <p className="text-sm mt-2">{product.description}</p>
              <button className="mt-2 bg-blue-500 text-white px-4 py-1 rounded">Contact Seller</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}